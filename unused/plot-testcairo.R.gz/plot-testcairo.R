
library(Cairo)

CairoFontMatch(fontpattern="Bitstream Charter",sort=FALSE,verbose=FALSE)
##1. family: "Bitstream Charter", style: "Roman", file:
##"/Users/iaw4/Library/Fonts/bchr8a.otf"

CairoFonts( regular="Bitstream Charter:style=Regular" )
## you may also want to set the other four R fonts, as described in the docs.

CairoPDF(file="testcairo.pdf")
plot( c(0,1), c(0,1) )
text( 0.5, 0.5, "This is Bitstream Charter in Cairo")
dev.off
