
base::source("wmapaux.Rinclude")

## test out color range
plotvar <- c(-0.1,0.1,seq( -20, 5, 1 ))  ## more range on the left
rwg <- mkrwg( plotvar )

o <- as.data.frame(do.call("rbind", lapply(  1:length(plotvar), function(wi) {
    ## cnvx is a little big buggy here, because -0.1 should be E6E6E6 rather than E6E3E3
    ## but this is just a test function
    cnvx <- function(x) (x - min(plotvar))/(max(plotvar)-min(plotvar))
    mci <- as.integer(cnvx( plotvar[wi] )*(length( rwg )-1)) + 1
    data.frame(obs=wi, val=plotvar[wi], calcindex=mci, coli=rwg[mci])
})))
    
print(o)
plot( o$val, (1:length(o$val)) %% 2, col=o$coli, cex=5, pch=16 ) ## zero value in gray

################################################################
## now integrate into rworldmap
################################################################

dev.new()  ## draw another figure now

plot.world(c("USA", "MEX", "BRA", "RUS", "SDN", "CHN", "NZL", "AUS"),
           c(-4,    -3,    -3,    -2,    -1,     0,    0.5,    1) )
