
#' OOSLM
#'
#' @name ooslm
#'
#'  out-of-sample linear model
#'
#' @usage ooslm (formula, starti, data, winlen=999999)
#'
#' @param formula on the data
#' @param the first observation
#' 
#' @return recursive residuals net of unconditional residuals
#'
#' @seealso 

ooslm <- function(formula, starti, data, maxwinlen=999999) {

    getResponse <- function(form, data) {
        mf <- match.call(expand.dots = FALSE)
        m <- match(c("formula", "data"), names(mf), 0L)
        mf <- mf[c(1L, m)]
        mf$drop.unused.levels <- TRUE
        mf[[1L]] <- as.name("model.frame")
        mf <- eval(mf, parent.frame())
        y <- model.response(mf, "numeric")
        y
    }

    resids1fun <-  function( i ) {
        to.predict <- getResponse( formula, data )

        sr <- max(1, i-maxwinlen):i

        estdata <- data[sr,]
        predlm <- lm( formula, estdata )

        print( data[i+1,] )
        predmedata <-data[i+1,]

        p1 <- predict( predlm, newdata=predmedata )

        message( "now pred")
        str(p1)
        str(predmedata)

        print(predict( predlm, newdata= data[i+1,] ))
        stop("AAA")

        condesterr <- to.predict[i+1] - predict( predlm, newdata= data[i+1,] )
        message("Condesterr = ", condesterr)
        uncondesterr <- to.predict[i+1] - mean( to.predict[sr] )
        c( abs(uncondesterr) - abs(condesterr), uncondesterr, condesterr )
    }

    print(resids1fun(20))
    # rr <- lapply( starti:nrow(data), resids1fun)
    # print(rr)
    stop("OK")
    return(rr)
}

N <- 30

df <- data.frame( x <- rnorm(N), y <- rnorm(N), z <- rnorm(N) )

formula <- y ~ x + z

cat("

ooslm( formula, 20, df )

")
