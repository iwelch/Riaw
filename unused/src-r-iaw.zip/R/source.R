
#' SOURCE
#'
#' @name source
#'
#' replaces the original source but adds the current source file name as an global attr to source.  Ergo, it keeps track
#' of the source call sequences.  Note---this is *not* the call stack.
#'
#' further, this source also recognizes Rmd files
#'
#' @usage source (filename, ...)
#'
#' @param Rsourcefilename
#'
#' @return
#'

iaw$source <- function (Rsourcefilename, ...) {
    if (grepl("\\.Rinclude", Rsourcefilename)) return(base:::source(Rsourcefilename))
    (grepl("\\.R$",Rsourcefilename)) %or% "can only iaw$source file .R files [or .Rinclude] not {{Rsourcefilename}} with such an extension"
    (is.null(iaw$ARGV0)) %or% "cannot nest iaw$source.  please use base:::source() instead."

    ## if ((!file.exists(Rsourcefilename))&(file.exists(paste0(Rsourcefilename, "md"))))
    ## Rsourcefilename <- paste0(Rsourcefilename, "md")

    ## if (grepl("\\.Rmd$",Rsourcefilename)) {
    ## message("[Sourcing Working Rmd file ", Rsourcefilename, "]")
    ## p <- pipe(paste("Rmd2R.pl -i ", Rsourcefilename))
    ## iaw$msg.firstcall <- NULL
    ## base:::source( p, ...)
    ## close(p)
    ## } else

    {
        message("[Sourcing Working R file ", Rsourcefilename, "]")
        iaw$msg.firstcall <- NULL
        iaw$ARGV0 <<- Rsourcefilename
        base:::source(Rsourcefilename, ...)
        iaw$ARGV0 <<- NULL
    }
}
