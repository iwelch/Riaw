
#' KILL.USELESS.COLS
#'
#' @name kill.useless.cols
#'
#' remove all columns in a data frame that have no variance
#'
#' @usage kill.useless.cols (d)
#'
#' @param a data frame
#'
#' @return a new dataframe
#'

iaw$kill.useless.cols <- function (d) {
  killlist <- NULL
  for (i in 1:ncol(d)) if (length(unique(d[, i])) == 1) killlist = c(killlist, i)
  d[-killlist]
}
