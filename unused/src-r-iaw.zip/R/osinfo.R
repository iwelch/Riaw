
#' Operating System Information
#'
#' @name osinfo
#'
#' osinfo gives system information, trying to figure out the OS.
#'
#' @return one of macos, linux, or windows.
#'


iaw$osinfo <- function(){
    if (any(grepl("darwin", R.version))) return( c(os="macos") )
    if (any(grepl("linux-gnu", R.version))) return( c(os="linux") )
    c(os="windows")
}

