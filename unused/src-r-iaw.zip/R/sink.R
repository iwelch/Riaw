
#' SINK
#'
#' @name sink
#'
#' makes sure to overwrite only .Rout files and to close any existing sink() files first.
#'
#'  @param file
#'
#'  @return
#'

iaw$sink.withpid <- FALSE


iaw$sink <- function (file = NULL, verbose= FALSE, ...) {

  sink.goodbye <- function(verbose=FALSE) {
      if (!sink.number()) { warning("no sink file to close"); return(NULL); }

      herenow <- Sys.time()
      if (!is.null(attr( iaw$sink, "startingtime"))) {
          delta <- Sys.time() - attr(iaw$sink, "startingtime")
          if (verbose) iaw$msg( "[pid=", Sys.getpid(), ": now=", iaw$now(), "=", herenow, "; ",
                               "started=", as.character(attr(iaw$sink, "startingtime")), "=", as.numeric(attr(iaw$sink, "startingtime")),
                               ". lapsed time=", delta, units(delta), "]" )
          ## attr(sink, "startingtime") <<- NULL
          ## attr(sink, "file") <<- file
      } else { if (verbose) iaw$msg("[sink bye]") }
      base:::sink(NULL)  ## actual closing
  }


  if (!is.null(file)) {
    (grepl("\\.R$", file)) %and% "you cannot sink to an .R file.  you probably want to sink to an Rout file"
    (grepl("\\.Rout$", file)) %or% "you can sink only to an Rout file, i.e., not to a {{file}} file"

    if (sink.number()) {
        warning("I am closing your previous sink file ",attr(iaw$sink, "file")," for you first, before opening another.\n")
        sink.goodbye()
    }

    ## this is "sink.hello()"
    herenow <- Sys.time()
    if (iaw$sink.withpid) file <- paste0(file, "-", Sys.getpid())

    base::sink(file=file, ...)
    if (verbose) iaw$msg( "[pid=",Sys.getpid(), ": logfile=", file, ": now=", herenow, "]" )
    attr(iaw$sink, "startingtime") <<- herenow
    attr(iaw$sink, "file") <<- file

  } else {
      sink.goodbye()
  }

}
