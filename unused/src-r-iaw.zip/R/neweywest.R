
iaw$olm <- function(...) {
    stop("please use newey-west input in iaw$olm")
}
