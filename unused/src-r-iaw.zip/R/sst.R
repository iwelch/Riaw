
#' SST
#'
#' @name sst
#'
#'  the sum-squared-total
#'
#' @usage sst (model)
#'
#' @param model a (usually lm) model
#'
#' @return the sum-squared total
#'

iaw$sst <- function (model) sum(fitted(model)^2) + iaw$sse(model)
