
#' NORMALIZE, STANDARDIZE
#'
#' @name normalize
#'
#' reference message
#'
#' @usage normalize (object)
#'
#' @return error
#'
#' @aliases standardize
#'
#' @seealso scale


iaw$normalize <- function (object)
    iaw$abort("use scale(object) instead of normalize(object)")
