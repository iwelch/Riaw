
#' Beep
#'
#' @name beep
#'
#' make some sound if you can.
#'

iaw$beep <- function() system("beep")
