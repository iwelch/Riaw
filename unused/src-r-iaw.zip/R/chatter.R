## system("rm -rf /opt/homebrew/lib/R/*chatter*")

chatter.toggle.state <- "verbose"

chatter <- function( quiet.verbose ) {
    if (chatter.toggle.state == "") return(0);  ## don't do anything!

    stopifnot( quiet.verbose %in% c("quiet","verbose","") )

    if (quiet.verbose == "quiet") {
        if ( chatter.toggle.state != "verbose" ) message("warning --- chatter was not verbose")
        chatter.toggle.state <<- "quiet"
        filecon <<- file("/tmp/R-suppressed.Rout", "w")
        message("[suppressing chatter now (quiet) for loading of standard R libraries]")
        sink(file=filecon, type="message")
        sink(file=filecon, type="output")
    } else if (quiet.verbose == "verbose") {
        if ( chatter.toggle.state != "quiet" ) message("warning -- chatter was not quiet")
        chatter.toggle.state <<- "verbose"
        sink(file=NULL, type="output")
        sink(file=NULL, type="message")
        message("[chatter turned back on (verbose) for iaw progress]\n")
    }
}

