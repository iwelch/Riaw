
#' Exit Nicely
#'
#' @name exit
#'

exit <- function(...) {
    blankMsg <- sprintf("\r%s\r", paste(rep(" ", getOption("width")-1L), collapse=" "));
    stop(simpleError(blankMsg));
}
