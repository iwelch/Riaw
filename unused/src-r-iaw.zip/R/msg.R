
#' Print More Useful Message
#'
#' prints a message with "Time Since First Call" and Caller Function.  For better logging, this is sent to stdout, not stderr
#'
#' @name msg
#'
#' @param ... any text accepted by message
#'
#' @examples
#'   > msg("Hello")
#'    [1] TRUE
#'
#'   > sleep(2); msg("Again")
#'     <  =
#'     60 61
#'
#' @seealso message

iaw$messageln <- cmpfun(function(...) {
    cat("\n")
    boldblue <- "\033[34;1m"; boldred <- "\033[30;1m"; bold <- "\033[30;1m"; ansioff <- "\033[0m"
    if (interactive()) message(boldblue)
    cat(..., sep="")
    if (interactive()) message(ansioff)
    cat("\n")
})

iaw$msg.firstcall <- NULL  ## global carry

iaw$msg <- function(..., len.of.funname=12) {
    lnm <- as.list(sys.call(-1))
    snm <- as.character(if (length(lnm)==0) "global" else lnm[[1]])
    sformat <- paste0("%", len.of.funname, ".", len.of.funname, "s")
    curtime <- as.character(Sys.time())
    if (is.null(iaw$msg.firstcall)) iaw$msg.firstcall <<- curtime else curtime <- substr(as.character(curtime), 12, 100)
    iaw$messageln(
            "\n####----####----####----####----####----####----####----####----####----####----####----\n",
            as.character(curtime), ":[", sprintf("%04d",iaw$tmdiffsec(Sys.time(), iaw$msg.firstcall)), "s]",
            ":", sprintf(sformat, snm), ": ", ..., 
            "\n####----####----####----####----####----####----####----####----####----####----####----")
}
