
#' STANDARDIZE
#'
#' @name standardize
#'
#' an error with reference to the correct function to use
#'
#' @seealso scale
#'

iaw$standardize <- function(...) iaw$abort("use scale()")
