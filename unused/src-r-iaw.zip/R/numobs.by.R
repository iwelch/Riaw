

#' NUMBER OF OBERVATIONS OF (AS.FACTOR) VARIABLE
#'
#' @name numobs.by
#'
#' an error with reference to the correct function to use
#'
#' @seealso table
#'

iaw$numobs.by <- function (...) iaw$abort("use table()")
