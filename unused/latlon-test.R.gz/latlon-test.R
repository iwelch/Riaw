
################################################################                                    

message("There must be ", 361*181, " cells in the array, though 360 and 180 should be rarely used, so 64800 should usually be enough\n")

message("The following *must* be different")
print( iaw$latlon( c(0.5, -0.5) ) )
print( iaw$latlon( c(-0.5, -0.5) ) )
print( iaw$latlon( c(-0.5, 0.5) ) )
print( iaw$latlon( c(0.5, 0.5) ) )

message("Smallest")
print( iaw$latlon( c(-90, -180) ) )
message("Largest")
print( iaw$latlon( c(90, 180) ) )

message("Middle")
print( iaw$latlon( c(0, 0) ) )

message("Inversion LO (0 and 1)")
print( iaw$latlon( 1 ) )
print( iaw$latlon( c(-90, -180 )) )

message("Inversion HI (64799 and 64800)")
print( iaw$latlon( 64799 ) )
print( iaw$latlon( 64800 ) )

message("OK")
print( iaw$latlon( c(90, 180) ) )

message("LOOP NOW")

for (id in 1:(360*180)) {
    if (id != iaw$latlon( iaw$latlon( id ) )) {
        message("**************** BROKEN ID = ", id)
        print( iaw$latlon( id ) )
        print( iaw$latlon( iaw$latlon( id ) ) )
        stop("broken")
    }
}

message("latlonid ok: max=", iaw$latlon( 90.0, 180.0), "\n")



################################################################
## The following is the loose coordinate system from latitude to longitude that DOE used


mkgeiaidv <- function( latlon2 ) mkgeiaid( latlon2[1], latlon2[2] )
mkgeiaid <- function( lat, lon ) as.integer( (lat+90+0.5)*1000+(lon+180+0.5) + 0.0001 )
invgeia <- function( geiaid ) { c( lat=as.integer( geiaid/1000)-90 -0.5, lon=as.integer((geiaid%%1000)-180  )) }

message("The following *must* be different")
print( mkgeiaidv( c(0.5, -0.5) ) )
print( mkgeiaidv( c(-0.5, -0.5) ) )
print( mkgeiaidv( c(-0.5, 0.5) ) )
print( mkgeiaidv( c(0.5, 0.5) ) )

for (id in 0:400000) {
    if (id != mkgeiaidv( invgeia( id ) )) {
        message("ID = ", id)
        print( invgeia( id ) )
        print( mkgeiaidv( invgeia( id ) ) )
        stop("broken")
    }
}

message("geiaid ok: max=", mkgeiaid( 90.0, 180.0), "\n")
