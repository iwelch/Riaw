
NT <- 50
match <- c( intercept=0.2, ar1=0.90, expsigma=(-0.1) )

sim.and.est.1 <- function( i, p ) {

    ## simulate some process, say true ar1
    set.seed( i ); e <- rnorm(NT, 0, exp(p[3]))
    s <- c( 0.2, numeric(NT-1) )
    for (t in 2:NT) s[t] <- p[1] + p[2]*s[t-1] + e[t]

    ## estimate an OLS ar1
    a <- lm.fit( cbind(1, s[1:(NT-1)]), s[2:NT] )
    c( coef(a), expsigma= log(sd(resid(a)) ))
}

mcsapply <- function( iter, fun, ... ) { simplify2array(mclapply( iter, fun, ... )) }
penalty <- function( a, b ) mean( (a-b)^2 )

result <- optim(par=c(1.0, 0.0, 0.05),
                fn=function( guess3, MC=1000 ) {
                    ## message( paste( p3, collapse=" " ) )
                    simsests <- t(mcsapply( 1:MC, function(i) sim.and.est.1(i, guess3) ))
                    thisone <- colMeans( simsests )
                    ov <- penalty( thisone , match )

                    ## if we are close, sample more
                    if (ov < 1e-2) {
                        ## add precision
                        simsests <- rbind(simsests, t(mcsapply( 1:MC*5, function(i) sim.and.est.1(i+MC, guess3) )))
                        thisone <- colMeans( simsests )
                        ov <- penalty( thisone , match )
                    }
                    ov
                },
                method="Nelder-Mead")

print(result)
